import Layout from '~/layouts'

export default {
  title: 'index - index2',
  menuOrder: 3,
  layout: Layout,
}
