import Layout from '~/layouts'

export default {
  title: 'index - index1',
  menuOrder: 2,
  layout: Layout,
}
