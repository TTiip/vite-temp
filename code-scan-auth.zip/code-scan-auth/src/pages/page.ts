import Layout from '~/layouts'

export default {
  title: 'index - 首页',
  menuOrder: 1,
  layout: Layout,
}
