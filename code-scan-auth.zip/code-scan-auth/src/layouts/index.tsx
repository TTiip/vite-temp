import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Layouts',
  setup () {
    return () => (
      <div class="flex h-screen">
        112233
        <router-view />
      </div>
    )
  },
})
