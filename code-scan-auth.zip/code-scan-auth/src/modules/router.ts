import type { Router } from 'vue-router'

export default (_: any, { router }: { router: Router }) => {
  router.beforeEach(async to => {

  })
}
